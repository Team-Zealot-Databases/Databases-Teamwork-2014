# Documentation

## Database Schema - Diagram

![screenshot](https://raw.githubusercontent.com/Team-Zealot-Databases/Databases-Teamwork-2014/master/Documentation/Images/Database%20Schema.png)

## Program - User Interface

![screenshot](https://raw.githubusercontent.com/Team-Zealot-Databases/Databases-Teamwork-2014/master/Documentation/Images/Program%20-%20UI.png)
