namespace RobotsFactory.MySQL
{
    using System;
    using System.Linq;

    public class JsonReport
    {
        public int ReportId { get; set; }

        public string JsonContent { get; set; }
    }
}