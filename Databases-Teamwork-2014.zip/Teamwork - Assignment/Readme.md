![screenshot](https://raw.githubusercontent.com/Team-Zealot-Databases/Databases-Teamwork-2014/master/Teamwork%20-%20Assignment/teamwork-assignment.jpg)
